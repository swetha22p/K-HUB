// app.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 5000; // Choose your desired port

// Middleware
app.use(bodyParser.json());
app.use(cors());

// MongoDB connection
mongoose.connect('mongodb://0.0.0.0:27017/excel_data', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
mongoose.connection.on('connected', () => {
  console.log('Connected to MongoDB');
});

// Create a MongoDB schema for the data
const excelDataSchema = new mongoose.Schema({}, { strict: false });
const ExcelData = mongoose.model('ExcelData', excelDataSchema);

// Route for saving the data
app.post('/api/saveExcelData', (req, res) => {
  const data = req.body;

  if (!data || !Array.isArray(data)) {
    return res.status(400).json({ error: 'Invalid data format' });
  }

  // Save the data to MongoDB
  ExcelData.insertMany(data, (err) => {
    if (err) {
      return res.status(500).json({ error: 'Error saving data to the database' });
    }
    return res.status(200).json({ message: 'Data saved successfully' });
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});